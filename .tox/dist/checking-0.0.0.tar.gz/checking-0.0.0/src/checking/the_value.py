from dataclasses import dataclass

# from enum import Enum


@dataclass
class ValueList:
    Blue: int = 10
    Red: int = 200
    Yellow: int = 3000
